from django.shortcuts import render, redirect
from .forms import ReseñaForm
from .models import Reseña

def agregar_reseña(request):
    if request.method == 'POST':
        form = ReseñaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_reseñas')
    else:
        form = ReseñaForm()
    return render(request, 'reseñas/agregar_reseña.html', {'form': form})

def lista_reseñas(request):
    reseñas = Reseña.objects.all().order_by('-id')
    return render(request, 'reseñas/lista_reseñas.html', {'reseñas': reseñas})