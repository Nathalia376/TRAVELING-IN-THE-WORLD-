from django.db import models

class Reseña(models.Model):
    destino_id = models.IntegerField()
    usuario = models.CharField(max_length=100)
    calificacion = models.IntegerField(choices=[(i, str(i)) for i in range(1, 6)])
    comentario = models.TextField()

    def __str__(self):
        return f"{self.usuario} - {self.destino_id}"