from django.urls import path
from . import views

urlpatterns = [
    path('nueva/', views.agregar_reseña, name='agregar_reseña'),
    path('', views.lista_reseñas, name='lista_reseñas'),
]